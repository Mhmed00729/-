<?php
import telebot
import requests
Api_Token = input('[→] Enter Token The Bot : ')
bot = telebot.TeleBot(Api_Token)
@bot.message_handler(commands = ["start"])
def Markos(message):
    bot.send_message(message.chat.id,text=f"*أرسل الايميل: *",parse_mode="markdown")
    @bot.message_handler(func=lambda U:True ) 
    def Checker(message):
        email = message.text
        api = "http://mrez.pythonanywhere.com/api/Marko/email={}".format(str(email))
        req = requests.get(api).text
        if str('True') in str(req):
            bot.send_message(message.chat.id,text=f"*البريد مربوط ✅*",parse_mode="markdown")
        else:
            bot.send_message(message.chat.id,text=f"*البريد غير مربوط ⛔*",parse_mode="markdown")
bot.polling(True)